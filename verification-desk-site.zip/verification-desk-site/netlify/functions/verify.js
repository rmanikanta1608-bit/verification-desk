// Netlify Function: verify.js
// Holds the Anthropic API key server-side and proxies fact-check requests
// from the front end. The API key is read from an environment variable —
// never hardcode it here.

const SYSTEM_PROMPT = `You are a rigorous fact-checking researcher. Given a claim, use web search to find real, current, credible news or reference sources that confirm, deny, or contextualize it. Then respond with ONLY a raw JSON object (no markdown fences, no prose before or after) matching exactly this shape:

{
  "verdict": "true" | "false" | "unclear",
  "confidence": "low" | "medium" | "high",
  "explanation": "2-4 sentence plain-language explanation of what the evidence shows, written for a general reader",
  "sources": [
    { "title": "exact article title", "publisher": "publication name", "url": "https://..." }
  ]
}

Rules:
- Only include sources you actually found via search, with real URLs. Never invent a URL or title.
- Include 2-5 sources when available. If you truly found none, return an empty sources array.
- Use "unclear" when evidence is mixed, the claim is unverifiable, or it's opinion/prediction rather than a checkable fact.
- Do not include any text outside the JSON object.`;

function extractJSON(text) {
  const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start === -1 || end === -1) throw new Error('No JSON object found in model response');
  return JSON.parse(cleaned.slice(start, end + 1));
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  let claim;
  try {
    const body = JSON.parse(event.body || '{}');
    claim = (body.claim || '').trim();
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid request body' }) };
  }

  if (!claim) {
    return { statusCode: 400, body: JSON.stringify({ error: 'No claim provided' }) };
  }
  if (claim.length > 2000) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Claim is too long' }) };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'Server is missing ANTHROPIC_API_KEY' }) };
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages: [
          { role: 'user', content: `Claim to check: "${claim}"` }
        ],
        tools: [
          { type: 'web_search_20250305', name: 'web_search' }
        ]
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      return {
        statusCode: response.status,
        body: JSON.stringify({ error: 'Anthropic API error: ' + errText.slice(0, 300) })
      };
    }

    const data = await response.json();
    const fullText = (data.content || [])
      .map((item) => (item.type === 'text' ? item.text : ''))
      .filter(Boolean)
      .join('\n');

    const parsed = extractJSON(fullText);

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(parsed)
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Server error: ' + err.message })
    };
  }
};
