# The Verification Desk

A news-claim checker: paste a claim, it uses Claude with live web search to
research it, then returns a verdict (Confirmed / Disputed / Unconfirmed) with
linked sources.

The Anthropic API key lives only in the serverless function
(`netlify/functions/verify.js`), never in the browser.

## Deploy on Netlify (free tier works)

Netlify Drop (drag-and-drop) does **not** support serverless functions, so
this needs the Git-based deploy path instead — still free, just one extra step.

1. **Create a GitHub repo** and push this folder to it
   (or use Netlify CLI — see below — if you'd rather skip GitHub).

2. **Get an Anthropic API key**
   Go to https://console.anthropic.com → API Keys → Create Key.
   Note: this uses your own Anthropic account and will incur normal API usage
   costs per request (this is separate from any Claude.ai subscription).

3. **Connect the repo to Netlify**
   - Go to https://app.netlify.com → "Add new site" → "Import an existing project"
   - Pick your GitHub repo
   - Build settings: leave build command empty, publish directory `.`
     (netlify.toml already configures this)

4. **Add your API key as an environment variable**
   - In the Netlify site dashboard: Site configuration → Environment variables
   - Add: `ANTHROPIC_API_KEY` = `sk-ant-...` (your key)
   - Redeploy the site so the function picks it up

5. **Done** — Netlify gives you a public URL like
   `https://your-site-name.netlify.app`. Anyone can open it and use the tool.

## Alternative: deploy without GitHub, using Netlify CLI

```bash
npm install -g netlify-cli
cd verification-desk-site
netlify deploy --prod
```

Follow the prompts to log in and create a new site. Then set the environment
variable either via the CLI:

```bash
netlify env:set ANTHROPIC_API_KEY sk-ant-your-key-here
netlify deploy --prod
```

or in the Netlify dashboard as in step 4 above.

## Local testing

```bash
npm install -g netlify-cli
netlify dev
```

This runs the site and function locally with hot reload, reading
`ANTHROPIC_API_KEY` from a local `.env` file (create one — don't commit it).
